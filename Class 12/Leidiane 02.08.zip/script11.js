

console.log("helloworld");

var exemplo1 = {
    "paulo":20,
    "americo":100

}

var shape = {
    "height": 10,
    "width":10,

    area: function(){
        return this.height*this.width;
    }
}


console.log(exemplo1["paulo"]);
console.log(exemplo1[0]);

console.log(shape.area);
console.log(shape["area"]);

console.log(shape.area());


/* To reduce the area size
shape.height = 5;
shape.width = 5; or like the way it is written below/*/

shape.height = shape.height/2;//5;
shape.width = shape.width/2;//5;

console.log(shape.area());

/*declarar o objeto e estanciar a seguir (height and width below are attributes*/
function Shape(){
    this.height = 10;
    this.width = 10;

    this.area = function(){
        return this.height*this.width;
    };
};/*

/* 
function Shape (height.width){
    this.height = height;
    this.widht = widht;
    this.area = function(){
        return this.height*this.width;
}
/*

/*estanciar o objeto*/
var shape2 = new Shape();

console.log(shape2.area()); 


//estaciar um novo objeto//
var shape3 = new Shape();

shape3.height = shape.height/2;
shape3.width = shape.width/2;

//executando//
console.log(shape2.area());
console.log(shape3.area());

