## projecto da class 12

este procjecto foi criado para um momento teorico