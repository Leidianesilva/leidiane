## projeto da classe 12

este projeto foi criado por um momento teorico ou prático do curso up academy